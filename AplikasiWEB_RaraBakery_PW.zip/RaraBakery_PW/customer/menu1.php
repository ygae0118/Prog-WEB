                                <li class="user-body">
                                    <div class="col-xs-4 text-center">
                                        <a href="customer.php">Customer</a>
                                    </div>
                                    <div class="col-xs-4 text-center">
                                        <a href="produk.php">Produk</a>
                                    </div>
                                </li>