
<br/>
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index1.php">
                                <i class="glyphicon glyphicon-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="active">
                            <a href="index.php">
                                <i class="glyphicon glyphicon-file"></i> <span>Belanja Lagi</span>
                            </a>
                        </li>
                    </ul>
                    