<?php require_once("conn.php");
    if (!isset($_SESSION)) {
        session_start();
    } ?>
<!DOCTYPE html>
<html lang="en">

<?php include "head.php"; ?>
<body>
    
	<?php include "header.php"; ?>
	


	<!-- start: Slider -->
	<div id="page-title">

		<div id="page-title-inner">

			<!-- start: Container -->
			<div class="container">

				<h2><i class="ico-stats ico-white"></i>Profil</h2>

			</div>
			<!-- end: Container  -->

		</div>	

	</div>
	<!-- end: 
	<!-- end: Slider -->
			
	<!--start: Wrapper-->
	<div id="wrapper">
				
		<!--start: Container -->
    	<div class="container">
	
      		<!-- start: Hero Unit - Main herounit for a primary marketing message or call to action -->

<section class="about p-5" id="about">
  <div style="text-align: left;" class="container mt-3">
    <div class="row mb-3">
      <div class="col text-center">
        <h2>
          
          ABOUT STORE <br>----

        </h2> 
      </div>
    </div>
     <div class="row justify-content-center">
       <div class="col-md-5 text-justify">
         <p>
           RARA STORE merupakan toko kue yang telah berdiri sejak Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor sit amet.
         </p>
       </div>

       <div class="col-md-5 text-justify">
         <p>
           RARA CAKE STORE hanya dibuka pada pukul Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum Lorem ipsum dolor sit amet.
         </p>
       </div>
     </div> 
  </div>

</section>
<!-- CONTAK -->
<section id="contact" class="contact p-5">

    <div class="container mt-3 ">
      <div class="row ">
        <div class="col text-center">
            <H2>KONTAK <br> -------</H2>
        </div>
        
      </div>

      <div class="row justify-content-center">
        <div class="col-lg-4">
          <div class="card   mb-3" id="cardcontak">
           
               <div class="card-body" >
                  <h5 class="card-title">Kontak</h5>
                  <font>No Telp : 0852-9217-466</font>
                    <p class="card-text">Silahkan mendatangi lokasi jika ingin order secara langsung !!!. . .
                     </p>
               </div>
            </div>

            <ul class="list-group">
              <li class="list-group-item">LOCATION</li>
              <li class="list-group-item">Beji</li>
              <li class="list-group-item">Taji</li>
              <li class="list-group-item">Prambanan, Klaten</li>
              <li class="list-group-item">Indonesia</li>
            </ul>
          </div>
            
          </div>

        </div>

    </div>

</section>

		
			<hr>
			 <BR><BR><BR>
        <BR><BR><BR>
            <BR><BR><BR>
            <BR><BR><BR>
        <BR><BR><BR>
            <BR><BR><BR>
	<div id="footer-menu" class="hidden-tablet hidden-phone">
		<center>
			<br>
			<font>2021 @ RARA CAKE STORE</font>
		</center>
<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery-1.8.2.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/flexslider.js"></script>
<script src="../js/carousel.js"></script>
<script src="../js/jquery.cslider.js"></script>
<script src="../js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>